import axios from 'axios';
import React, { useEffect, useState } from 'react'
// import { Link } from "react-router-dom";
// import { useContext } from "react";
// import { VoterContext } from "./Context/Context";

import {contract, web3} from './contract';
import Notification from './components/Notification';
import TokenData from './components/TokenData';

function SendNft() {

    const [fileImg, setFileImg] = useState(null);
    const [name, setName] = useState("")
    const [desc, setDesc] = useState("")
    const [accAddress, setAccAddress] = useState(null);
    const [accounts, setAccounts] = useState([]);
    const [tokenId, setTokenId] = useState(null);
    const [token, setToken] = useState({});

    const [errorMessage, setErrorMessage] = useState('')
    const [notificationClass, setNotificationClass] = useState('success')

    // const { votingSystemContract, currentAccount, setTokenID, winner } = useContext(VoterContext)


    const sendJSONtoIPFS = async (ImgHash) => {

        try {

            let data = {
                "name": name,
                "description": desc,
                "image": ImgHash
            }

            const transactionParameters = {
                from: accAddress,
              };
              
              contract.methods
                .mintNFT(data)
                .send(transactionParameters)
                .on('transactionHash', function(hash) {
                  console.log('Transaction Hash:', hash);
                })
                .on('confirmation', function(confirmationNumber, receipt) {
                  console.log('Confirmation Number:', confirmationNumber);
                  console.log('Receipt:', receipt);
                  let tokenId = receipt.events.Transfer.returnValues.tokenId;
                  setTokenId(tokenId);
                  showNotificationMsg('success', `Mint successful with Token ${tokenId}`)
                })
                .on('error', function(error, receipt) {
                  console.error(error);
                  showNotificationMsg('error', error.message)
                });

        } catch (error) {
            console.log(error);
            showNotificationMsg('error', error.message);
        }


    }

    const sendFileToIPFS = async (e) => {

        e.preventDefault();

        if (fileImg) {
            try {

                const formData = new FormData();
                formData.append("file", fileImg);

                axios({
                    method: "post",
                    url: "https://api.pinata.cloud/pinning/pinFileToIPFS",
                    data: formData,
                    headers: {
                        'pinata_api_key': `${process.env.REACT_APP_PINATA_API_KEY}`,
                        'pinata_secret_api_key': `${process.env.REACT_APP_PINATA_API_SECRET}`,
                        "Content-Type": "multipart/form-data"
                    },
                }).then( res => {

                const ImgHash = `ipfs://${res.data.IpfsHash}`;
                sendJSONtoIPFS(ImgHash)
              });

            } catch (error) {
                console.log(error);
                showNotificationMsg('error', error.message);
            }
        }
    }

    const fetchAccounts = () =>{
        web3.eth.getAccounts().then(accs =>{
            setAccounts(accs)
        });
    }

    const getTxnData = () =>{
       
         contract.methods.getTokenMetadata(tokenId).call({from: accAddress}).then( data =>{
            if (!data['name']) {
                showNotificationMsg('error', 'No data found.')
                return;
            }
            console.log('getTokenMetadata', data);
            let token = {
                name: data['name'],
                description: data['description'],
                image: data['image'].split('//')[1]
            }
            setToken(token);
         })
    }

    const handleTokenChnage = (e) =>{
        setTokenId(e.target.value)
    }

    const showNotificationMsg = (msgType, msg) => {
        setErrorMessage(msg)
        setNotificationClass(msgType)
        setTimeout(()=>{
          setErrorMessage('')
        }, 3000);
      }

    useEffect(() => {
        fetchAccounts()
        console.log(fileImg)
    }, [fileImg])


    return (
        <div className='mt-3 text-center'>
            <h2 className='text-white mb-3'>Send NFT</h2>
            { 
            (errorMessage) &&
                <Notification message={errorMessage} notificationClass={notificationClass}/>
            }
            <div>
                Choose Account: <select onChange={(e) => setAccAddress(e.target.value)}>
                <option value=''></option>
                {  
                    accounts.map(address =>{
                        return <option value={address} key={address}>{address}</option>
                    })
                }
                </select>
            </div>
            <div>Selected Account address: {accAddress}</div>
            <div>
                <form onSubmit={sendFileToIPFS}>
                    <input type="file" onChange={(e) => setFileImg(e.target.files[0])} required />
                    <input type="text" onChange={(e) => setName(e.target.value)} placeholder='name' required value={name} />
                    <input type="text" onChange={(e) => setDesc(e.target.value)} placeholder="desc" required value={desc} />
                    <br />
                    <button className='bttn_ui me-3' type='submit' >Mint NFT</button>
                    
                </form>
                {
                    (tokenId) && <p>Token ID: {tokenId}</p>
                }
            </div>
            <div>
                <input onChange={handleTokenChnage}  value={tokenId} placeholder='Token ID' type='text'></input>
                <button onClick={()=>getTxnData()}>Get metadata</button>
            </div>
            <TokenData token={token}/>
        </div>
    )
}

export default SendNft