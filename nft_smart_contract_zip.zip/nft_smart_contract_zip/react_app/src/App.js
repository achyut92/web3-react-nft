import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import contract from './contract';

function App() {
  const [contractData, setContractData] = useState(null);

  useEffect(() => {
    async function fetchData() {
      const result = await contract.methods.mintNFT({name:'achyut', description:'test description', image: null}).call(); // Replace with the name of your smart contract's method
      console.log(result);
      setContractData(result);
    }
    fetchData();
  }, []);
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <p>{contractData}</p>
      </header>
    </div>
  );
}

export default App;
