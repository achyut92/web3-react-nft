import Web3 from 'web3';
import contractJson from './abi/MyNFT.json';

const web3 = new Web3("http://localhost:7545"); // Replace with the URL of your local or remote Ethereum network
const contractAddress = `${process.env.REACT_APP_CONTRACT_ADDRESS}`; // Replace with your smart contract's address in .env.local file
const contract = new web3.eth.Contract(contractJson, contractAddress);
window.web3 = web3;

export { 
    contract,
    web3
}
