
const TokenData = ({ token }) => {
    
    if (!token.name) {
      return null
    }
  
    return (
      <div> 
          <h3>Metadata</h3>
          <p>Name: {token.name}</p>
          <p>Description: {token.description}</p>
          { token.name != null && <img src={`https://gateway.pinata.cloud/ipfs/${token.image}`} alt={token.name}></img> }
      </div>
    )
  }

  export default TokenData