module.exports = {
    networks: {
      development: {
        host: "127.0.0.1",
        port: 7545, // Or the port number you have set for your local Ganache network
        network_id: "*" // Match any network id
      }
    },
    compilers: {
      solc: {
        version: "0.8.9" // Or the version of Solidity that your contract uses
      }
    }
  };
  