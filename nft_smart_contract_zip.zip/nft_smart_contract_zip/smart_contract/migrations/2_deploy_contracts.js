var MyContract = artifacts.require ("MyNFT");
module.exports = function(deployer) {
      deployer.deploy(MyContract);
}